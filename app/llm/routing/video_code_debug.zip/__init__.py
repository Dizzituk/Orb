# FILE: app/llm/routing/__init__.py
"""Routing subpackage.

The main public API remains `app.llm.router`. Modules in here are internal
organization only.
"""

__all__ = [
    "core",
]
